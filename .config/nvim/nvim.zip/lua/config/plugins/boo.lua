return {
  {
    'LukasPietzschmann/boo.nvim',
    opts = {
      -- here goes your config :)
    },
    init = function ()
      require("boo").setup()
    end
  }
}
