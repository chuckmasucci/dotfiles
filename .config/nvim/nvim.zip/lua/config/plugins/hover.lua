return {
  'JASONews/glow-hover',
  init = function ()
    require'glow-hover'.setup {
      -- The followings are the default values
      max_width = 50,
      padding = 10,
      border = 'shadow',
      glow_path = 'glow'
    }
  end
}
