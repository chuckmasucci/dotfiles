return {
  "ojroques/nvim-bufdel",
  init = function()
    require('bufdel').setup()
  end
}

