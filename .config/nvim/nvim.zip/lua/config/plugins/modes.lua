return {
  {
    'mvllow/modes.nvim',
    tag = 'v0.2.0',
    init = function()
      require('modes').setup()
    end
  }
}
