return {
  {
    "j-hui/fidget.nvim",
    init = function ()
     require("fidget").setup()
    end
  }
}
