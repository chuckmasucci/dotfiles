return {
  "neovim/nvim-lspconfig",
}
