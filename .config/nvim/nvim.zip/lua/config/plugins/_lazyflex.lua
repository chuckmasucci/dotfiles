return {
  {
    "abeldekat/lazyflex.nvim",
    version = "*",
    cond = true,
    import = "lazyflex.hook",
    -- opts = { enable_match = true, kw = { "nvim-treesitter", "mason", "lspconfig", "tabout", "dracula" }},
  },
}
