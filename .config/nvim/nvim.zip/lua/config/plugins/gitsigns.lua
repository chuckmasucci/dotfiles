return {
  {
    "lewis6991/gitsigns.nvim",
    init = function ()
      require('gitsigns').setup()
    end
  }
}
